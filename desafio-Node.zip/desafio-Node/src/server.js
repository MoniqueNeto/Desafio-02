// Importação CommonJS modules
const app = require('./app');

// Rodar a aplicação express na porta 3000
app.listen(3000);
