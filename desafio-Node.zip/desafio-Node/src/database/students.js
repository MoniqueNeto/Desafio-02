const students = {
  1: {
    registration: '20192EWBJ0329', name: 'ants@discente.ifpe.edu.br', email: 'Adryel do Nascimento Torres Silva', birth_date: '13/04/2000', id: 1,
  },
  2: {
    registration: '20192EWBJ0191', name: 'apa1@discente.ifpe.edu.br', email: 'Alysson Pereira Assunção', birth_date: '13/10/1993', id: 2,
  },
  3: {
    registration: '20192EWBJ0280', name: 'atss1@discente.ifpe.edu.br', email: 'Ana Thamyres Santana Santos', birth_date: '16/11/2001', id: 3,
  },
  4: {
    registration: '20192EWBJ0175', name: 'dcs12@discente.ifpe.edu.br', email: 'Deise Cristiane Silva', birth_date: '28/06/2000', id: 4,
  },
  5: {
    registration: '20192EWBJ0060', name: 'edxb@discente.ifpe.edu.br', email: 'Eduardo Duarte Xavier de Brito', birth_date: '23/04/1998', id: 5,
  },
  6: {
    registration: '20192EWBJ0264', name: 'gvm1@discente.ifpe.edu.br', email: 'Gabriel Vasconcelos Marques', birth_date: '04/08/1995', id: 6,
  },
  7: {
    registration: '20192EWBJ0124', name: 'ijrs1@discente.ifpe.edu.br', email: 'Igor José Ribeiro dos Santos', birth_date: '02/09/1999', id: 7,
  },
  8: {
    registration: '20192EWBJ0086', name: 'jrss1@discente.ifpe.edu.br', email: 'Jéssica Roberta de Souza Santos', birth_date: '29/06/1996', id: 8,
  },
  9: {
    registration: '20192EWBJ0019', name: 'jwbs@discente.ifpe.edu.br', email: 'José Weverton Barros da Silva', birth_date: '15/02/2001', id: 9,
  },
  10: {
    registration: '20192EWBJ0256', name: 'krts@discente.ifpe.edu.br', email: 'Kaique Rierickson Torres Silva', birth_date: '14/01/2002', id: 10,
  },
  11: {
    registration: '20192EWBJ0205', name: 'mrcs2@discente.ifpe.edu.br', email: 'Maria Raquel Cordeiro Santos', birth_date: '30/04/2001', id: 11,
  },
  12: {
    registration: '20192EWBJ0035', name: 'mtfn@discente.ifpe.edu.br', email: 'Monique Tereza Ferreira Neto', birth_date: '17/01/2001', id: 12,
  },
  13: {
    registration: '20211EWBJ0299', name: 'agfl@discente.ifpe.edu.br', email: 'Andressa Girlaine Firmino de Lima', birth_date: '08/01/2001', id: 13,
  },
  14: {
    registration: '20221EWBJ0173', name: 'dlaa@discente.ifpe.edu.br', email: 'David Lucas Alves de Almeida', birth_date: '27/07/2003', id: 14,
  },
  15: {
    registration: '20221EWBJ0041', name: 'jgls3@discente.ifpe.edu.br', email: 'José Gabriel de Lira dos Santos', birth_date: '03/06/2003', id: 15,
  },
  16: {
    registration: '20221EWBJ0050', name: 'jmss6@discente.ifpe.edu.br', email: 'José Mirosmar Santos Silva', birth_date: '23/10/2002', id: 16,
  },
  17: {
    registration: '20211EWBJ0213', name: 'mgaa@discente.ifpe.edu.br', email: 'Maria Gabrielly de Almeida Araújo', birth_date: '27/05/1998', id: 17,
  },
  18: {
    registration: '20221EWBJ0165', name: 'yps2@discente.ifpe.edu.br', email: 'Yago Pedro da Silva', birth_date: '20/06/2001', id: 18,
  },
  19: {
    registration: '20192EWBJ0230', name: 'noxa@discente.ifpe.edu.br', email: 'Nicholas Oliveira Xavier Alvee', birth_date: '20/05/1999', id: 19,
  },
  20: {
    registration: '20221EWBJ0157', name: 'tbs13@discente.ifpe.edu.br', email: 'Tomas Braz da Silva ', birth_date: '25/05/2004', id: 20,
  },
};

module.exports = students;
